"""
AI Khan — Complete Single-File Backend v3.0 (FINAL)
Run: pip install fastapi uvicorn yfinance pandas numpy && python main.py
"""

import logging
import time
import threading
import numpy as np
import pandas as pd
import yfinance as yf
try:
    import feedparser
except ImportError:
    feedparser = None

from datetime import datetime
from typing import Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("ai_khan")

# ─────────────────────────────────────────────────────────────────────────────
# UNIVERSE — NSE + BSE combined (~165 stocks)
# ─────────────────────────────────────────────────────────────────────────────

NIFTY200_STOCKS = [
    {"symbol": "RELIANCE.NS",   "name": "Reliance Industries",         "sector": "Energy"},
    {"symbol": "TCS.NS",        "name": "Tata Consultancy Services",   "sector": "IT"},
    {"symbol": "HDFCBANK.NS",   "name": "HDFC Bank",                   "sector": "Banking"},
    {"symbol": "INFY.NS",       "name": "Infosys",                     "sector": "IT"},
    {"symbol": "ICICIBANK.NS",  "name": "ICICI Bank",                  "sector": "Banking"},
    {"symbol": "HINDUNILVR.NS", "name": "Hindustan Unilever",          "sector": "FMCG"},
    {"symbol": "ITC.NS",        "name": "ITC Ltd",                     "sector": "FMCG"},
    {"symbol": "SBIN.NS",       "name": "State Bank of India",         "sector": "Banking"},
    {"symbol": "BAJFINANCE.NS", "name": "Bajaj Finance",               "sector": "NBFC"},
    {"symbol": "BHARTIARTL.NS", "name": "Bharti Airtel",               "sector": "Telecom"},
    {"symbol": "KOTAKBANK.NS",  "name": "Kotak Mahindra Bank",         "sector": "Banking"},
    {"symbol": "LT.NS",         "name": "Larsen & Toubro",             "sector": "Capital Goods"},
    {"symbol": "HCLTECH.NS",    "name": "HCL Technologies",            "sector": "IT"},
    {"symbol": "ASIANPAINT.NS", "name": "Asian Paints",                "sector": "Paints"},
    {"symbol": "AXISBANK.NS",   "name": "Axis Bank",                   "sector": "Banking"},
    {"symbol": "MARUTI.NS",     "name": "Maruti Suzuki",               "sector": "Auto"},
    {"symbol": "SUNPHARMA.NS",  "name": "Sun Pharmaceuticals",         "sector": "Pharma"},
    {"symbol": "TITAN.NS",      "name": "Titan Company",               "sector": "Consumer"},
    {"symbol": "WIPRO.NS",      "name": "Wipro",                       "sector": "IT"},
    {"symbol": "ONGC.NS",       "name": "ONGC",                        "sector": "Oil & Gas"},
    {"symbol": "NTPC.NS",       "name": "NTPC",                        "sector": "Power"},
    {"symbol": "POWERGRID.NS",  "name": "Power Grid Corp",             "sector": "Power"},
    {"symbol": "ULTRACEMCO.NS", "name": "UltraTech Cement",            "sector": "Cement"},
    {"symbol": "NESTLEIND.NS",  "name": "Nestle India",                "sector": "FMCG"},
    {"symbol": "MM.NS",         "name": "Mahindra & Mahindra",         "sector": "Auto"},
    {"symbol": "TATAMOTORS.NS", "name": "Tata Motors",                 "sector": "Auto"},
    {"symbol": "TATASTEEL.NS",  "name": "Tata Steel",                  "sector": "Metal"},
    {"symbol": "HINDALCO.NS",   "name": "Hindalco Industries",         "sector": "Metal"},
    {"symbol": "JSWSTEEL.NS",   "name": "JSW Steel",                   "sector": "Metal"},
    {"symbol": "ADANIPORTS.NS", "name": "Adani Ports",                 "sector": "Infrastructure"},
    {"symbol": "COALINDIA.NS",  "name": "Coal India",                  "sector": "Mining"},
    {"symbol": "TECHM.NS",      "name": "Tech Mahindra",               "sector": "IT"},
    {"symbol": "DRREDDY.NS",    "name": "Dr. Reddy's Laboratories",    "sector": "Pharma"},
    {"symbol": "DIVISLAB.NS",   "name": "Divi's Laboratories",         "sector": "Pharma"},
    {"symbol": "CIPLA.NS",      "name": "Cipla",                       "sector": "Pharma"},
    {"symbol": "APOLLOHOSP.NS", "name": "Apollo Hospitals",            "sector": "Healthcare"},
    {"symbol": "BAJAJFINSV.NS", "name": "Bajaj Finserv",               "sector": "NBFC"},
    {"symbol": "GRASIM.NS",     "name": "Grasim Industries",           "sector": "Cement"},
    {"symbol": "INDUSINDBK.NS", "name": "IndusInd Bank",               "sector": "Banking"},
    {"symbol": "EICHERMOT.NS",  "name": "Eicher Motors",               "sector": "Auto"},
    {"symbol": "HEROMOTOCO.NS", "name": "Hero MotoCorp",               "sector": "Auto"},
    {"symbol": "BRITANNIA.NS",  "name": "Britannia Industries",        "sector": "FMCG"},
    {"symbol": "BPCL.NS",       "name": "BPCL",                        "sector": "Oil & Gas"},
    {"symbol": "SHREECEM.NS",   "name": "Shree Cement",                "sector": "Cement"},
    {"symbol": "BAJAJAUTO.NS",  "name": "Bajaj Auto",                  "sector": "Auto"},
    {"symbol": "PIDILITIND.NS", "name": "Pidilite Industries",         "sector": "Chemicals"},
    {"symbol": "HAVELLS.NS",    "name": "Havells India",               "sector": "Consumer Electric"},
    {"symbol": "MUTHOOTFIN.NS", "name": "Muthoot Finance",             "sector": "NBFC"},
    {"symbol": "GODREJCP.NS",   "name": "Godrej Consumer Products",    "sector": "FMCG"},
    {"symbol": "DABUR.NS",      "name": "Dabur India",                 "sector": "FMCG"},
    {"symbol": "MARICO.NS",     "name": "Marico",                      "sector": "FMCG"},
    {"symbol": "COLPAL.NS",     "name": "Colgate-Palmolive",           "sector": "FMCG"},
    {"symbol": "TATACONSUM.NS", "name": "Tata Consumer Products",      "sector": "FMCG"},
    {"symbol": "ICICIGI.NS",    "name": "ICICI General Insurance",     "sector": "Insurance"},
    {"symbol": "ICICIPRULI.NS", "name": "ICICI Prudential Life",       "sector": "Insurance"},
    {"symbol": "SBILIFE.NS",    "name": "SBI Life Insurance",          "sector": "Insurance"},
    {"symbol": "HDFCLIFE.NS",   "name": "HDFC Life Insurance",         "sector": "Insurance"},
    {"symbol": "AMBUJACEM.NS",  "name": "Ambuja Cements",              "sector": "Cement"},
    {"symbol": "ACC.NS",        "name": "ACC Limited",                 "sector": "Cement"},
    {"symbol": "VEDL.NS",       "name": "Vedanta",                     "sector": "Metal"},
    {"symbol": "HINDZINC.NS",   "name": "Hindustan Zinc",              "sector": "Metal"},
    {"symbol": "NMDC.NS",       "name": "NMDC",                        "sector": "Mining"},
    {"symbol": "SAIL.NS",       "name": "Steel Authority of India",    "sector": "Metal"},
    {"symbol": "TATAPOWER.NS",  "name": "Tata Power",                  "sector": "Power"},
    {"symbol": "ADANIGREEN.NS", "name": "Adani Green Energy",          "sector": "Renewable Energy"},
    {"symbol": "CANBK.NS",      "name": "Canara Bank",                 "sector": "Banking"},
    {"symbol": "BANKBARODA.NS", "name": "Bank of Baroda",              "sector": "Banking"},
    {"symbol": "PNB.NS",        "name": "Punjab National Bank",        "sector": "Banking"},
    {"symbol": "FEDERALBNK.NS", "name": "Federal Bank",                "sector": "Banking"},
    {"symbol": "IDFCFIRSTB.NS", "name": "IDFC First Bank",             "sector": "Banking"},
    {"symbol": "BANDHANBNK.NS", "name": "Bandhan Bank",                "sector": "Banking"},
    {"symbol": "AUROPHARMA.NS", "name": "Aurobindo Pharma",            "sector": "Pharma"},
    {"symbol": "TORNTPHARM.NS", "name": "Torrent Pharmaceuticals",     "sector": "Pharma"},
    {"symbol": "BIOCON.NS",     "name": "Biocon",                      "sector": "Pharma"},
    {"symbol": "LUPIN.NS",      "name": "Lupin",                       "sector": "Pharma"},
    {"symbol": "ALKEM.NS",      "name": "Alkem Laboratories",          "sector": "Pharma"},
    {"symbol": "JUBLFOOD.NS",   "name": "Jubilant Foodworks",          "sector": "Retail"},
    {"symbol": "DMART.NS",      "name": "Avenue Supermarts (DMart)",   "sector": "Retail"},
    {"symbol": "TRENT.NS",      "name": "Trent",                       "sector": "Retail"},
    {"symbol": "MPHASIS.NS",    "name": "Mphasis",                     "sector": "IT"},
    {"symbol": "LTIM.NS",       "name": "LTIMindtree",                 "sector": "IT"},
    {"symbol": "PERSISTENT.NS", "name": "Persistent Systems",          "sector": "IT"},
    {"symbol": "COFORGE.NS",    "name": "Coforge",                     "sector": "IT"},
    {"symbol": "OFSS.NS",       "name": "Oracle Financial Services",   "sector": "IT"},
    {"symbol": "KPIT.NS",       "name": "KPIT Technologies",           "sector": "IT"},
    {"symbol": "NYKAA.NS",      "name": "Nykaa",                       "sector": "Internet"},
    {"symbol": "PAYTM.NS",      "name": "Paytm",                       "sector": "Fintech"},
    {"symbol": "IRCTC.NS",      "name": "IRCTC",                       "sector": "Travel"},
    {"symbol": "LICI.NS",       "name": "LIC India",                   "sector": "Insurance"},
    {"symbol": "NHPC.NS",       "name": "NHPC",                        "sector": "Power"},
    {"symbol": "RECLTD.NS",     "name": "REC Limited",                 "sector": "Finance"},
    {"symbol": "PFC.NS",        "name": "Power Finance Corp",          "sector": "Finance"},
    {"symbol": "IRFC.NS",       "name": "Indian Railway Finance Corp", "sector": "Finance"},
    {"symbol": "ZOMATO.NS",     "name": "Zomato",                      "sector": "Internet"},
    {"symbol": "POLICYBZR.NS",  "name": "PB Fintech (PolicyBazaar)",   "sector": "Internet"},
    {"symbol": "ADANIENT.NS",   "name": "Adani Enterprises",           "sector": "Conglomerate"},
    {"symbol": "SIEMENS.NS",    "name": "Siemens India",               "sector": "Capital Goods"},
    {"symbol": "ABB.NS",        "name": "ABB India",                   "sector": "Capital Goods"},
    {"symbol": "BOSCHLTD.NS",   "name": "Bosch Ltd",                   "sector": "Auto Ancillary"},
    {"symbol": "DIXON.NS",      "name": "Dixon Technologies",          "sector": "Electronics"},
    {"symbol": "VOLTAS.NS",     "name": "Voltas",                      "sector": "Consumer Electric"},
]

BSE_ADDITIONS = [
    {"symbol": "ADANIPOWER.BO",  "name": "Adani Power",        "sector": "Power"},
    {"symbol": "CESC.BO",        "name": "CESC Limited",       "sector": "Power"},
    {"symbol": "CONCOR.BO",      "name": "Container Corp",     "sector": "Logistics"},
    {"symbol": "DLF.BO",         "name": "DLF Limited",        "sector": "Real Estate"},
    {"symbol": "GODREJPROP.BO",  "name": "Godrej Properties",  "sector": "Real Estate"},
    {"symbol": "HDFCAMC.BO",     "name": "HDFC AMC",           "sector": "Finance"},
    {"symbol": "IOC.BO",         "name": "Indian Oil Corp",    "sector": "Oil & Gas"},
    {"symbol": "JSWENERGY.BO",   "name": "JSW Energy",         "sector": "Power"},
    {"symbol": "KALYANKJIL.BO",  "name": "Kalyan Jewellers",   "sector": "Retail"},
    {"symbol": "LALPATHLAB.BO",  "name": "Dr Lal PathLabs",    "sector": "Healthcare"},
    {"symbol": "MAZDOCK.BO",     "name": "Mazagon Dock",       "sector": "Defence"},
    {"symbol": "MRF.BO",         "name": "MRF",                "sector": "Auto Ancillary"},
    {"symbol": "NAUKRI.BO",      "name": "Info Edge (Naukri)", "sector": "Internet"},
    {"symbol": "OBEROIRLTY.BO",  "name": "Oberoi Realty",      "sector": "Real Estate"},
    {"symbol": "PAGEIND.BO",     "name": "Page Industries",    "sector": "Apparel"},
    {"symbol": "SBICARD.BO",     "name": "SBI Cards",          "sector": "Finance"},
    {"symbol": "SJVN.BO",        "name": "SJVN Limited",       "sector": "Power"},
    {"symbol": "SUZLON.BO",      "name": "Suzlon Energy",      "sector": "Renewable Energy"},
    {"symbol": "TORNTPOWER.BO",  "name": "Torrent Power",      "sector": "Power"},
    {"symbol": "UNIONBANK.BO",   "name": "Union Bank",         "sector": "Banking"},
    {"symbol": "VARUNBEV.BO",    "name": "Varun Beverages",    "sector": "Beverages"},
    {"symbol": "ZEEL.BO",        "name": "Zee Entertainment",  "sector": "Media"},
    {"symbol": "SUPREMEIND.BO",  "name": "Supreme Industries", "sector": "Plastics"},
    {"symbol": "IREDA.BO",       "name": "IREDA",              "sector": "Finance"},
    {"symbol": "INOXWIND.BO",    "name": "Inox Wind",          "sector": "Renewable Energy"},
    {"symbol": "INDIANB.BO",     "name": "Indian Bank",        "sector": "Banking"},
]

NSE_MIDCAP_ADDITIONS = [
    {"symbol": "ANGELONE.NS",    "name": "Angel One",             "sector": "Finance"},
    {"symbol": "ASTRAL.NS",      "name": "Astral Ltd",            "sector": "Plastics"},
    {"symbol": "BLUESTARCO.NS",  "name": "Blue Star",             "sector": "Consumer Electric"},
    {"symbol": "CANFINHOME.NS",  "name": "Can Fin Homes",         "sector": "Housing Finance"},
    {"symbol": "CROMPTON.NS",    "name": "Crompton Greaves",      "sector": "Consumer Electric"},
    {"symbol": "DELHIVERY.NS",   "name": "Delhivery",             "sector": "Logistics"},
    {"symbol": "EMAMILTD.NS",    "name": "Emami Ltd",             "sector": "FMCG"},
    {"symbol": "FINEORG.NS",     "name": "Fine Organic",          "sector": "Chemicals"},
    {"symbol": "GLAND.NS",       "name": "Gland Pharma",          "sector": "Pharma"},
    {"symbol": "HAPPSTMNDS.NS",  "name": "Happiest Minds",        "sector": "IT"},
    {"symbol": "INDHOTEL.NS",    "name": "Indian Hotels (Taj)",   "sector": "Hospitality"},
    {"symbol": "KAYNES.NS",      "name": "Kaynes Technology",     "sector": "Electronics"},
    {"symbol": "KFINTECH.NS",    "name": "KFin Technologies",     "sector": "Finance"},
    {"symbol": "LAURUSLABS.NS",  "name": "Laurus Labs",           "sector": "Pharma"},
    {"symbol": "MASTEK.NS",      "name": "Mastek",                "sector": "IT"},
    {"symbol": "MAXHEALTH.NS",   "name": "Max Healthcare",        "sector": "Healthcare"},
    {"symbol": "METROPOLIS.NS",  "name": "Metropolis Healthcare", "sector": "Healthcare"},
    {"symbol": "NAVINFLUOR.NS",  "name": "Navin Fluorine",        "sector": "Chemicals"},
    {"symbol": "RITES.NS",       "name": "RITES Ltd",             "sector": "Infrastructure"},
    {"symbol": "SOLARINDS.NS",   "name": "Solar Industries",      "sector": "Defence"},
    {"symbol": "SONACOMS.NS",    "name": "Sona BLW Precision",    "sector": "Auto Ancillary"},
    {"symbol": "STAR.NS",        "name": "Star Health Insurance", "sector": "Insurance"},
    {"symbol": "TATACHEM.NS",    "name": "Tata Chemicals",        "sector": "Chemicals"},
    {"symbol": "TATACOMM.NS",    "name": "Tata Communications",   "sector": "Telecom"},
    {"symbol": "TATAELXSI.NS",   "name": "Tata Elxsi",            "sector": "IT"},
    {"symbol": "TRIDENT.NS",     "name": "Trident Ltd",           "sector": "Textiles"},
    {"symbol": "VGUARD.NS",      "name": "V-Guard Industries",    "sector": "Consumer Electric"},
    {"symbol": "WELCORP.NS",     "name": "Welspun Corp",          "sector": "Metal"},
    {"symbol": "ZENTEC.NS",      "name": "Zen Technologies",      "sector": "Defence"},
    {"symbol": "BIKAJI.NS",      "name": "Bikaji Foods",          "sector": "FMCG"},
    {"symbol": "CLEAN.NS",       "name": "Clean Science Tech",    "sector": "Chemicals"},
    {"symbol": "CONCORDBIO.NS",  "name": "Concord Biotech",       "sector": "Pharma"},
    {"symbol": "JKTYRE.NS",      "name": "JK Tyre",               "sector": "Auto Ancillary"},
    {"symbol": "KANSAINER.NS",   "name": "Kansai Nerolac",        "sector": "Paints"},
    {"symbol": "ROUTE.NS",       "name": "Route Mobile",          "sector": "IT"},
    {"symbol": "SWSOLAR.NS",     "name": "Sterling Wilson Solar", "sector": "Renewable Energy"},
    {"symbol": "TIMKEN.NS",      "name": "Timken India",          "sector": "Industrial"},
    {"symbol": "NETWORK18.NS",   "name": "Network18",             "sector": "Media"},
    {"symbol": "CRISIL.NS",      "name": "CRISIL",                "sector": "Finance"},
    {"symbol": "ELECON.NS",      "name": "Elecon Engineering",    "sector": "Capital Goods"},
]

ALL_STOCKS = NIFTY200_STOCKS + NSE_MIDCAP_ADDITIONS + BSE_ADDITIONS


# ─────────────────────────────────────────────────────────────────────────────
# TECHNICAL INDICATORS
# ─────────────────────────────────────────────────────────────────────────────

def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta    = close.diff()
    gain     = delta.clip(lower=0)
    loss     = -delta.clip(upper=0)
    avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()
    rs       = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def macd(close: pd.Series, fast=12, slow=26, signal=9):
    ema_fast    = close.ewm(span=fast,   adjust=False).mean()
    ema_slow    = close.ewm(span=slow,   adjust=False).mean()
    macd_line   = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram   = macd_line - signal_line
    return macd_line, signal_line, histogram

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high  = df["High"]
    low   = df["Low"]
    close = df["Close"]
    tr = pd.concat([
        high - low,
        (high - close.shift()).abs(),
        (low  - close.shift()).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(span=period, adjust=False).mean()

def volume_ratio(volume: pd.Series, period: int = 20) -> pd.Series:
    avg = volume.rolling(period).mean()
    return volume / avg.replace(0, np.nan)

def support_resistance(df: pd.DataFrame, lookback: int = 5):
    recent     = df.tail(lookback * 5)
    support    = float(recent["Low"].min())
    resistance = float(recent["High"].max())
    return support, resistance

def bullish_rsi_divergence(close: pd.Series, rsi_s: pd.Series, lookback: int = 25) -> bool:
    try:
        c = close.iloc[-lookback:]
        r = rsi_s.iloc[-lookback:]
        price_low_now  = c.iloc[-1] < c.iloc[:-1].min() * 1.02
        rsi_higher_now = r.iloc[-1] > r.iloc[:-1].min() * 1.05
        return bool(price_low_now and rsi_higher_now)
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────────
# MARKET INTELLIGENCE
# ─────────────────────────────────────────────────────────────────────────────

def _safe_pct(symbol: str, period: str = "5d") -> float:
    try:
        df = yf.Ticker(symbol).history(period=period, interval="1d", auto_adjust=True)
        if len(df) >= 2:
            return round((df["Close"].iloc[-1] / df["Close"].iloc[-2] - 1) * 100, 2)
    except Exception:
        pass
    return 0.0

def compute_fear_greed() -> dict:
    try:
        vix_df   = yf.Ticker("^INDIAVIX").history(period="5d",  interval="1d")
        nifty_df = yf.Ticker("^NSEI").history(period="30d", interval="1d")
        vix_now  = float(vix_df["Close"].iloc[-1]) if not vix_df.empty else 15
        nifty_mom = 0.0
        if len(nifty_df) >= 20:
            nifty_mom = (nifty_df["Close"].iloc[-1] / nifty_df["Close"].iloc[-20] - 1) * 100
        vix_score = max(0, min(100, 100 - (vix_now - 10) * 4))
        mom_score = max(0, min(100, 50 + nifty_mom * 3))
        score     = int(vix_score * 0.5 + mom_score * 0.5)
        if score >= 75:   label = "Extreme Greed"
        elif score >= 55: label = "Greed"
        elif score >= 45: label = "Neutral"
        elif score >= 25: label = "Fear"
        else:             label = "Extreme Fear"
        return {"score": score, "label": label, "vix": round(vix_now, 2)}
    except Exception:
        return {"score": 50, "label": "Neutral", "vix": 15.0}

def compute_sector_strength() -> list:
    sectors = [
        {"name": "IT",     "symbol": "^CNXIT"},
        {"name": "Bank",   "symbol": "^NSEBANK"},
        {"name": "Auto",   "symbol": "^CNXAUTO"},
        {"name": "Pharma", "symbol": "^CNXPHARMA"},
        {"name": "FMCG",   "symbol": "^CNXFMCG"},
        {"name": "Metal",  "symbol": "^CNXMETAL"},
        {"name": "Energy", "symbol": "^CNXENERGY"},
        {"name": "Infra",  "symbol": "^CNXINFRA"},
    ]
    result = []
    for s in sectors:
        chg = _safe_pct(s["symbol"])
        result.append({"name": s["name"], "change": chg})
    return sorted(result, key=lambda x: x["change"], reverse=True)

def fetch_news() -> list:
    """Fetch real market news from Economic Times + Moneycontrol RSS (free, no API key)."""
    try:
        import feedparser
    except ImportError:
        return []

    FEEDS = [
        ("https://economictimes.indiatimes.com/markets/stocks/news/rssfeeds/2146842.cms", "Economic Times"),
        ("https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms",           "ET Markets"),
        ("https://www.moneycontrol.com/rss/marketsnews.xml",                               "Moneycontrol"),
        ("https://www.moneycontrol.com/rss/latestnews.xml",                                "Moneycontrol"),
    ]
    KEYWORDS = [
        "stock", "market", "nifty", "sensex", "trade", "buy", "sell",
        "rally", "bull", "bear", "ipo", "result", "earning", "profit",
        "revenue", "rbi", "fed", "rate", "inflation", "rupee",
    ]
    seen, items = set(), []
    for url, source in FEEDS:
        try:
            import feedparser as fp
            feed = fp.parse(url)
            for e in feed.entries[:6]:
                title = e.get("title", "").strip()
                if not title or title in seen:
                    continue
                if not any(k in title.lower() for k in KEYWORDS):
                    continue
                seen.add(title)
                items.append({
                    "title":     title,
                    "publisher": source,
                    "link":      e.get("link", "#"),
                })
                if len(items) >= 8:
                    break
        except Exception:
            pass
        if len(items) >= 8:
            break
    return items

def market_overview() -> list:
    indices = [
        {"name": "NIFTY 50",   "symbol": "^NSEI"},
        {"name": "SENSEX",     "symbol": "^BSESN"},
        {"name": "NIFTY BANK", "symbol": "^NSEBANK"},
        {"name": "INDIA VIX",  "symbol": "^INDIAVIX"},
        {"name": "NIFTY IT",   "symbol": "^CNXIT"},
        {"name": "NIFTY MID",  "symbol": "^NSEMDCP50"},
    ]
    result = []
    for idx in indices:
        try:
            df = yf.Ticker(idx["symbol"]).history(period="5d", interval="1d", auto_adjust=True)
            if not df.empty and len(df) >= 2:
                price = round(float(df["Close"].iloc[-1]), 2)
                chg   = round((df["Close"].iloc[-1] / df["Close"].iloc[-2] - 1) * 100, 2)
                result.append({"name": idx["name"], "price": price, "change": chg})
        except Exception:
            pass
    return result


# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL ENGINE
# ─────────────────────────────────────────────────────────────────────────────

SIGNAL_THRESHOLD = 80
MIN_CANDLES      = 200
ATR_TARGET_MULT  = 2.5
ATR_SL_MULT      = 1.0
MAX_SIGNALS      = 12
MIN_AVG_VOLUME   = 50_000
MIN_PRICE        = 10.0

def _fetch_ohlcv(symbol: str) -> Optional[pd.DataFrame]:
    try:
        df = yf.Ticker(symbol).history(period="1y", interval="1d", auto_adjust=True)
        if df.empty or len(df) < MIN_CANDLES:
            return None
        df.dropna(inplace=True)
        if df["Volume"].tail(20).mean() < MIN_AVG_VOLUME:
            return None
        if float(df["Close"].iloc[-1]) < MIN_PRICE:
            return None
        return df
    except Exception:
        return None

def _score_stock(df: pd.DataFrame, symbol: str, name: str, sector: str) -> Optional[dict]:
    close  = df["Close"]
    volume = df["Volume"]

    ema9   = close.ewm(span=9,   adjust=False).mean()
    ema21  = close.ewm(span=21,  adjust=False).mean()
    ema50  = close.ewm(span=50,  adjust=False).mean()
    ema200 = close.ewm(span=200, adjust=False).mean()

    rsi_s             = rsi(close, 14)
    macd_line, sig, _ = macd(close)
    atr_s             = atr(df, 14)
    vol_r             = volume_ratio(volume, 20)

    cur, prev  = -1, -2
    price_now  = float(close.iloc[cur])
    rsi_now    = float(rsi_s.iloc[cur])
    macd_now   = float(macd_line.iloc[cur])
    sig_now    = float(sig.iloc[cur])
    macd_prev  = float(macd_line.iloc[prev])
    sig_prev   = float(sig.iloc[prev])
    ema9_now   = float(ema9.iloc[cur])
    ema21_now  = float(ema21.iloc[cur])
    ema50_now  = float(ema50.iloc[cur])
    ema200_now = float(ema200.iloc[cur])
    atr_now    = float(atr_s.iloc[cur])
    vol_now    = float(vol_r.iloc[cur]) if not np.isnan(vol_r.iloc[cur]) else 0.0
    ema21_prev = float(ema21.iloc[prev])
    price_prev = float(close.iloc[prev])

    score, conditions = 0, []

    # C1 — Long-term trend
    if price_now > ema200_now:
        score += 20
        pct = (price_now / ema200_now - 1) * 100
        conditions.append(f"Price {pct:.1f}% above 200 EMA — primary bull trend confirmed")

    # C2 — EMA21 reclaim
    if price_now > ema21_now and price_prev <= ema21_prev:
        score += 20
        conditions.append("Price reclaimed 21 EMA — short-term trend shift confirmed")
    elif price_now > ema21_now and price_now < ema21_now * 1.02:
        score += 10
        conditions.append("Price holding above 21 EMA — support confirmed")

    # C3 — MACD
    if macd_now > sig_now and macd_prev <= sig_prev:
        score += 20
        conditions.append("MACD bullish crossover — momentum confirmed")
    elif macd_now > sig_now and macd_now < 0:
        score += 10
        conditions.append("MACD bullish acceleration structure active")

    # C4 — RSI zone
    if 35 <= rsi_now <= 62:
        score += 15
        conditions.append(f"RSI {rsi_now:.1f} — optimal entry zone (not overbought)")
    elif 62 < rsi_now <= 70:
        score += 5
        conditions.append(f"RSI {rsi_now:.1f} — strong structural run")

    # C5 — Volume
    if vol_now >= 2.0:
        score += 15
        conditions.append(f"Volume {vol_now:.1f}x average — buyer accumulation")
    elif vol_now >= 1.5:
        score += 10
        conditions.append(f"Volume {vol_now:.1f}x average — elevated inflow")

    # C6 — EMA stack
    if ema9_now > ema21_now > ema50_now:
        score += 10
        conditions.append("EMA stack aligned (9 > 21 > 50) — long structure")
    elif ema9_now > ema21_now:
        score += 5
        conditions.append("Short-term EMAs stacked bullishly")

    # C7 — RSI divergence bonus
    if bullish_rsi_divergence(close, rsi_s, 25):
        score += 5
        conditions.append("Bullish RSI divergence detected")

    if score < SIGNAL_THRESHOLD:
        return None

    # Entry / target / SL calculation
    entry_low  = round(price_now * 0.995, 2)
    entry_high = round(price_now * 1.005, 2)
    try:
        _, resistance = support_resistance(df, lookback=5)
    except Exception:
        resistance = price_now + atr_now * ATR_TARGET_MULT

    target    = round(max(resistance, price_now + atr_now * ATR_TARGET_MULT), 2)
    stop_loss = round(min(price_now - atr_now * ATR_SL_MULT,
                          float(df["Low"].tail(10).min()) * 0.995), 2)
    risk      = price_now - stop_loss
    reward    = target - price_now
    rr        = round(reward / risk, 2) if risk > 0 else 0
    daily_m   = atr_now / price_now * 100
    days_lo   = max(5,  int(reward / (price_now * daily_m / 100) * 0.7))
    days_hi   = max(10, int(reward / (price_now * daily_m / 100) * 1.3))
    clean     = symbol.replace(".NS", "").replace(".BO", "")
    prefix    = "BSE:" if symbol.endswith(".BO") else "NSE:"

    # % move to target
    pct_to_target = round((target - price_now) / price_now * 100, 2)
    pct_to_sl     = round((price_now - stop_loss) / price_now * 100, 2)

    return {
        "id":            abs(hash(symbol + datetime.now().strftime("%Y-%m-%d"))) % 100_000,
        "symbol":        f"{prefix}{clean}",
        "ticker":        symbol,
        "name":          name,
        "sector":        sector,
        "type":          "BULLISH",
        "confidence":    min(score, 100),
        "score":         score,
        "entry":         f"₹{entry_low:.0f} – ₹{entry_high:.0f}",
        "entryLow":      entry_low,
        "entryHigh":     entry_high,
        "target":        f"₹{target:.0f}",
        "targetFloat":   target,
        "stoploss":      f"₹{stop_loss:.0f}",
        "stopFloat":     stop_loss,
        "rrRatio":       rr,
        "pctToTarget":   pct_to_target,
        "pctToSL":       pct_to_sl,
        "currentPrice":  round(price_now, 2),
        "atr":           round(atr_now, 2),
        "rsi":           round(rsi_now, 2),
        "volumeRatio":   round(vol_now, 2),
        "days":          f"{days_lo}–{days_hi}",
        "reason":        conditions[0] if conditions else "Multi-indicator confluence",
        "conditions":    conditions,
        "generatedAt":   datetime.now().isoformat(),
    }

def scan_for_signals(stocks: list) -> list:
    raw = []
    with ThreadPoolExecutor(max_workers=15) as ex:
        futures = {ex.submit(_fetch_ohlcv, s["symbol"]): s for s in stocks}
        for future in as_completed(futures):
            stock = futures[future]
            df    = future.result()
            if df is not None:
                res = _score_stock(df, stock["symbol"], stock["name"], stock["sector"])
                if res:
                    raw.append(res)
                    logger.info("✓ SIGNAL %s  score=%d  conf=%d%%",
                                res["symbol"], res["score"], res["confidence"])

    raw.sort(key=lambda x: x["confidence"], reverse=True)
    final, seen = [], {}
    for sig in raw:
        s = sig["sector"]
        if seen.get(s, 0) < 2:
            final.append(sig)
            seen[s] = seen.get(s, 0) + 1
        if len(final) >= MAX_SIGNALS:
            break
    return final


# ─────────────────────────────────────────────────────────────────────────────
# FASTAPI APP
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(title="AI Khan Backend", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_cache: dict     = {}
_scan_lock       = threading.Lock()

def _cached(key: str, ttl: int, fn, *args):
    entry = _cache.get(key)
    if entry and (time.time() - entry["ts"]) < ttl:
        return entry["data"]
    data = fn(*args)
    _cache[key] = {"data": data, "ts": time.time()}
    return data

def _background_scan():
    with _scan_lock:
        logger.info("▶ Starting full scan (%d stocks)…", len(ALL_STOCKS))
        t0      = time.time()
        signals = scan_for_signals(ALL_STOCKS)
        elapsed = round(time.time() - t0, 1)
        _cache["signals"] = {
            "data": {
                "signals":   signals,
                "count":     len(signals),
                "scannedAt": datetime.now().isoformat(),
                "scanTimeS": elapsed,
                "universe":  len(ALL_STOCKS),
            },
            "ts": time.time(),
        }
        logger.info("✅ Scan done in %.1fs — %d signals found", elapsed, len(signals))

@app.on_event("startup")
def startup():
    threading.Thread(target=_background_scan, daemon=True).start()

@app.get("/api/health")
def health():
    return {"status": "online", "version": "3.0.0", "universe": len(ALL_STOCKS)}

@app.get("/api/signals")
def get_signals():
    entry = _cache.get("signals")
    if not entry:
        return {"status": "scanning", "signals": [], "count": 0}
    return {"status": "ok", **entry["data"]}

@app.get("/api/signals/refresh")
def refresh(background_tasks: BackgroundTasks):
    if _scan_lock.locked():
        return {"status": "already_scanning"}
    _cache.pop("signals", None)
    background_tasks.add_task(_background_scan)
    return {"status": "queued"}

@app.get("/api/market-intel")
def get_intel():
    return {
        "status":    "ok",
        "fearGreed": _cached("fear_greed", 900, compute_fear_greed),
        "sectors":   _cached("sectors",    900, compute_sector_strength),
    }

@app.get("/api/news")
def get_news():
    return {"status": "ok", "news": _cached("news", 600, fetch_news)}

@app.get("/api/overview")
def get_overview():
    return {"status": "ok", "indices": _cached("overview", 300, market_overview)}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
